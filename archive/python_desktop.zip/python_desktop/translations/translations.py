# This file is intentionally empty as it should be generated
# The actual translations.py will be in utils/ directory