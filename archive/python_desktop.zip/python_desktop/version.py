"""
MP3Yap Version Information
"""

__version__ = "2.3.0"
__app_name__ = "YouTube MP3 İndirici"
__author__ = "Mehmet Yerli"
__github_repo__ = "mytsx/YtbMp3Indir"
