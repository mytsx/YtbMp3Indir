# Original Images

Bu klasör, uygulama için kullanılan orijinal görüntüleri içerir.

## İçerik

- **icon_original.png** - Uygulamanın ana ikonu (beyaz arka planlı orijinal versiyon)
- **icon_alternative.png** - Alternatif ikon tasarımı

## Not

Bu görüntüler ham halde saklanmaktadır. İşlenmiş ve kullanıma hazır ikonlar `assets/` klasöründedir.

İkon işleme için `scripts/` klasöründeki araçları kullanabilirsiniz.